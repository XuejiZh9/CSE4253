﻿namespace CrawfisSoftware.TicTacToeFramework
{
    public enum CellState
    {
        Blank,
        X,
        O
    }
}
